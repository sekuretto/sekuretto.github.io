<!DOCTYPE html>
<html>

   <head>
      <title>Laravel template by late almost</title>
   </head>

   <body>
      <h1>Laravel template by late almost</h1>
<hr>
	@yield('content')
<hr>

@yield('footer')

   </body>

</html>