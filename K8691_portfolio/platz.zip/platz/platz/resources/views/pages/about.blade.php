<p>Name by PHP-syntax: <?=$name; ?></p>
<p>Names by Laravel Blade Templating Syntax:<p>

<p>&lbrace;&lbrace; name &rbrace;&rbrace; : {{ $name }}</p>
<p>&lbrace;&excl;&excl; name &excl;&excl;&rbrace; : {!! $name !!}</p>
<p>PagesController/about-method</p>