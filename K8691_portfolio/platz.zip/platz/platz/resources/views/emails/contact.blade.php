<h3>Uusi yhteydenotto</h3>
<div>
    {{ $bodyMessage }}
</div>

<p>Lähettäjä {{ $email }}</p>